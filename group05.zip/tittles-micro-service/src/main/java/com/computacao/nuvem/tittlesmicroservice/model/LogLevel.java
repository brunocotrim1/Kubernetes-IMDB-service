package com.computacao.nuvem.tittlesmicroservice.model;

public enum LogLevel {
    TRACE,
    DEBUG,
    INFO,
    WARN,
    ERROR,
    FATAL
}
