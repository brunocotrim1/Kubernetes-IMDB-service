package com.computacao.nuvem.tittlesmicroservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EpisodeMicroServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EpisodeMicroServiceApplication.class, args);
	}

}
