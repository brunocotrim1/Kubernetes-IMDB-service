To run this project we need to first run the initial_script.bat that will be downloading and unzipping the datasets, after we need to execute the run_script.bat
this script will build the microservices and run our containerized microservices on docker, when the docker compose up command runs the containers will start up
but we need to wait aroung 10-20 min to the service be fully working since the dataset is around 10gb so the load takes a bit of time.
